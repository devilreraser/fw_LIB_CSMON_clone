/******************************************************************************/
/* User Level #define Macros                                                  */
/******************************************************************************/

/* TODO Application specific user parameters used in user.c may go here */

/******************************************************************************/
/* User Function Prototypes                                                   */
/******************************************************************************/

/* TODO User level functions prototypes (i.e. InitApp) go here */

/******************************************************************************/
/* User Level #define Macros                                                  */
/******************************************************************************/
#define _XTAL_FREQ SYS_FREQ  //used for __delay
/******************************************************************************/
/* User Function Prototypes                                                   */
/******************************************************************************/
void long_delay_ms (unsigned int ms);  //sample user function
void InitPorts (void);
void Initialize (void);
void ModbusEvents (void);
void ProgramLoop(void);
void ADC_Init(void);
unsigned int ADC_Read(unsigned char channel);
///void InitApp(void);         /* I/O and Peripheral Initialization */  changes