/******************************************************************************/
/* Files to Include                                                           */
/******************************************************************************/

#if defined(__XC)
    #include <xc.h>        /* XC8 General Include File */
#elif defined(HI_TECH_C)
    #include <htc.h>       /* HiTech General Include File */
#elif defined(__18CXX)
    #include <p18cxxx.h>   /* C18 General Include File */
#endif

#if defined(__XC) || defined(HI_TECH_C)

#include <stdint.h>        /* For uint8_t definition */
#include <stdbool.h>       /* For true/false definition */

#endif

#include "system.h"        /* System funct/params, like osc/peripheral config */
#include "user.h"          /* User funct/params, such as InitApp */
#include "modbus.h"

/******************************************************************************/
/* User Global Variable Declaration                                           */
/******************************************************************************/

/* i.e. uint8_t <variable_name>; */
volatile unsigned int  HoldingRegister[50] = {0};
volatile unsigned int  InputRegister[50] = {0};
extern volatile  int Coils[50] = {0}; ///// unsigned char sadasda
volatile unsigned char InputBits[50] = {0};
volatile unsigned char Response[125] = {0}; //Enough to return all holding-r's
volatile unsigned char Received[125] = {0}; //Enough to write all holding-r's
volatile char ModbusMessage,MessageLength;
//int adc=0;
extern volatile char TimerCount; 
////////
//////////int adc=0;
//////////double X1R=519.51,X2R=558.5,Y1=10,Y2=30,R1=1000,R2T=0,Vin=5,Vout=0,A=0,B=0,C=0;
//////////extern volatile double temp=0;
/////
////extern  double Ti=100,Td=1,Kp=1;
////extern  double integral=1,derivative=1,Ts=1,err=1,err1=1,setpoint=60,u1=1,u=1;
////extern  double b=1,a=1,c=1;
/******************************************************************************/
/* Main Program                                                               */
/******************************************************************************/

void main(void)
{
    /* Configure the oscillator for the device */
    ConfigureOscillator();
    //TRISBbits.TRISB0=0;
    //PORTBbits.RB0=0x01;
    
    /* Initialize I/O and Peripherals for application */
    //SetRegisters();
    InitApp();
    InitPorts();
    PWM_init();
    TRISCbits.TRISC2=0;
    PORTCbits.RC2 = 0;
    //PORTCbits.RC1 = 0;
    /* TODO <INSERT USER APPLICATION CODE HERE> */
    OpnUSART();
    ConfigInterrupts();
    ADC_Init();
    PWM_init();
    //ProgramLoop();
    while(1)
    {
    if(HoldingRegister[15]==1){
    PID();
        }
    ///////////////////////~~~~~~~~~~~~~~~~
    if(ModbusMessage){
      
      DecodeIt();
      
      //The modbusEvents procedure is called when a Modbus message is received
      ModbusEvents();           //enter your code in user.c under ModbusEvents
      
    }
    }
}

