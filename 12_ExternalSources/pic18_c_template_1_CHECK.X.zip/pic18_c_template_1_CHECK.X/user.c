/******************************************************************************/
/* Files to Include                                                           */
/******************************************************************************/

#if defined(__XC)
    #include <xc.h>         /* XC8 General Include File */
#elif defined(HI_TECH_C)
    #include <htc.h>        /* HiTech General Include File */
#elif defined(__18CXX)
    #include <p18cxxx.h>    /* C18 General Include File */
#endif

#if defined(__XC) || defined(HI_TECH_C)

#include <stdint.h>         /* For uint8_t definition */
#include <stdbool.h>        /* For true/false definition */

#endif

#include "system.h"        /* System funct/params, like osc/peripheral config */
#include "user.h"          /* User funct/params, such as InitApp */
#include "modbus.h"

extern volatile  int Coils[50];
extern volatile int REG=888;
extern volatile double temp;
extern volatile  double Kp=0.075,Ti=100,Td=1;
        

extern volatile int adc=0;
extern volatile int adcch=0;

//extern volatile float temp=0;
extern volatile double integral=1,derivative=1,Ts=1,
        err=1,
        err1=1,
        setpoint=60,
        u1=1,
        u=1,
        HighAlarm=60,
        LowAlarm=10;
extern volatile double b=1,a=1,c=1;
/******************************************************************************/
/* User Functions                                                             */
/******************************************************************************/

/* <Initialize variables in user.h and insert code for user algorithms.> */
void SetRegisters(void){
 //HoldingRegister[1]  ~~temp
setpoint=HoldingRegister[2]; //~~setpoint
Kp=HoldingRegister[3];  //~~Kp
Ti=HoldingRegister[4];  //~~Ti
Td=HoldingRegister[5];  //~~Td
adcch=HoldingRegister[6]; //~~ADC channel form 0 to 3  
Ts=HoldingRegister[7];  //~~ Discretization Time

b=HoldingRegister[8];   //~~koef
a=HoldingRegister[9];   //~~koef
c=HoldingRegister[10];   //~~koef
HighAlarm=HoldingRegister[11];   //~~High level alarm
LowAlarm=HoldingRegister[12];    //~~Low level alarm
//HoldingRegister[13] ~~High level alarm set bit
//HoldingRegister[14] ~~Low level alarm set bit
//HoldingRegister[15] ~~Reset Alarm bits
if(HoldingRegister[15]==1){   //~~ Reset Alarms
    HoldingRegister[13]=0;
    HoldingRegister[14]=0;
    }
}
        
void InitApp(void)
{
    /* TODO Initialize User Ports/Peripherals/Project here */

    /* Setup analog functionality and port direction */

    /* Initialize peripherals */

    /* Configure the IPEN bit (1=on) in RCON to turn on/off int priorities */

    /* Enable interrupts */
}

void long_delay_ms (unsigned int ms)
{
  unsigned int i;
   for (i = 0; i < ms; i++)
   __delay_ms(1)   ;
}

void InitPorts (void)

{ TRISCbits.TRISC1 = 0;
  TRISCbits.TRISC4 = 0 ; 
   
  
  TRISBbits.TRISB0=0;
  //TRISBbits.TRISB1=0;///////////
  PORTBbits.RB0=1;
  //PORTBbits.RB1=1;////////////////
  
}

void Initialize (void)
{ 
}
void ModbusEvents (void)
{ 
  
   SetRegisters();
   PORTBbits.RB0=Coils[1];
   //PORTBbits.RB1=Coils[0];
   HoldingRegister[5]=REG;
//   HoldingRegister[1]=temp;
   HoldingRegister[0]=91;
    //PORTBbits.RB0=1; //////here
}
void ProgramLoop(void)
{
  
}

void ADC_Init(void)
{
  TRISAbits.TRISA0 = 0xFF;
  ADCON0 = 0x81;               //Turn ON ADC and Clock Selection
  ADCON1 = 0x00;   //All pins as Analog Input and setting Reference Voltages
  //ADCON2bits.ACQT=7;
  
}

unsigned int ADC_Read(unsigned char channel)
{
  if(channel > 7)              //Channel range is 0 ~ 7
    return 0;

  ADCON0 &= 0xC5;              //Clearing channel selection bits
  ADCON0 |= channel<<3;        //Setting channel selection bits
  ADCON2bits.ADFM=1;
  ADCON1bits.VNCFG=0;
  ADCON1bits.VCFG0=0;
  ADCON1bits.VCFG1=0;
  ADCON2bits.ACQT=0x110;
  __delay_ms(20);               //Acquisition time to charge hold capacitor
  GO_nDONE=1;                //Initializes A/D conversion
  while(GO_nDONE);          //Waiting for conversion to complete
  return ((ADRESH<<8)+ADRESL); //Return result
}
///////////////////////////////////////////////////////
void PWM_init(void)

{
int dc=0;
TRISBbits.TRISB4 = 0 ;                     // set PORTC as output
PORTBbits.RB4 = 0 ;                     // clear PORTC
CCPTMRS = 0x00;
/*
* configure CCP module as 4000 Hz PWM output
*/
PR2 = 0xff ;
T2CON = 0b00000101 ;
CCP1CON = 0b00001100 ;
CCP2CON = 0b00111100 ;

}

/*
void upr(void)
{
    K=3.5;//posledno promeneni na 02.06.2016
    Ti=10;
    Td=3;
    Kp=K*(b*w-temp);
    Ki=(K/Ti)*(w-temp);
    Kd=K*Td*(c*w-temp);
    K1=Kp+Ki+Kd;
    K2=-Kp-2*Kd;
    K3=Kd;
    err2=err1;
    err1=err;
    err=setpoint-temp;
    u1=u;
    u=u1+K1*err+K2*err1+K3*err2;
    if(u>128){
        u=128;
    }
    if(u<0){
        u=0;
    }
    
    CCPR1L = u ;
    CCPR2L = 128 - u ;
}
*/
//////////
void PID(void){
    
    //int adc=0;
    double X1R=519.51,X2R=558.5,Y1=10,Y2=30,R1=1000,R2T=0,Vin=5,Vout=0,A=0,B=0,C=0;
    double temp=0;
    adc=ADC_Read(adcch);
    Vout=adc*0.001221;
    R2T=R1*(1/((Vin/Vout)-1));
    A=(R2T-X1R);
    B=((Y2-Y1)/(X2R-X1R));
    C=A*B+Y1;
    temp=C;
    HoldingRegister[1]=temp;
    if(temp>((1+(HighAlarm/100))*setpoint)){
        HoldingRegister[13]=1;    //High temperature alarm
    }
    if(temp<((LowAlarm/100)*setpoint)){
        HoldingRegister[14]=1;     //Low temperature alarm
    }
    err=setpoint-temp;
    integral=integral+(err*Ts);
    derivative=(err-err1)/(a*Ts);
    u=Kp*(b*setpoint-temp)+Ti*integral+Td*derivative;
    err1=err;
    if(u>128){
        u=128;
    }
    if(u<0){
        u=0;
    }
    
    CCPR1L = (int)u ;
    
    long_delay_ms((int)Ts*1000);
    
}