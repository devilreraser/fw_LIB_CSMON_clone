/******************************************************************************/
/* System Level #define Macros                                                */
/******************************************************************************/
#include <plib/usart.h>
/* TODO Define system operating frequency */

/* Microcontroller MIPs (FCY) */
#define SYS_FREQ        8000000L
#define FCY             SYS_FREQ/4

#define p18f26k80
#define Timer0High       0xF7 // 4MHz:0xFB, 8MHz:0xF7, 10MHz:0xF5, 20MHz:0xEB
#define Timer0Low        0xDF // 4MHz:0xEF, 8MHz:0xDF, 10MHz:0xD7, 20MHz:0xAF

#define BAUD_RATE        19200
#define SlaveAddress     2 // Slave addres

/******************************************************************************/
/* System Function Prototypes                                                 */
/******************************************************************************/

/* Custom oscillator configuration funtions, reset source evaluation
functions, and other non-peripheral microcontroller initialization functions
go here. */

void ConfigureOscillator(void); /* Handles clock switching/osc initialization */
void wait_ms(uint16_t time);

#ifdef p18f26k80
  #define BusyUsart        Busy1USART()      //For 18F8722 this is Busy1USART()
  #define TransmitBuffer   TXREG1            //For 18F8722 this is TXREG1
  #define ReceiveBuffer    RCREG1            //For 18F8722 this is RXREG1
  #define WriteEnable      LATCbits.LATC1    //this is RO/RE
  #define writeEnConf      TRISCbits.TRISC1  //to config RO/RE as output
  #define ReceiveFlag1     PIR1bits.RC1IF
  #define TransmitFlag1    PIR1bits.TX1IF
  #define Timer0Flag       INTCONbits.TMR0IF
#endif

/******************************************************************************/
/* System Function Prototypes                                                 */
/******************************************************************************/

void ConfigInterrupts(void);

void interrupt isr(void);

void ClsUSART(void);
void OpnUSART(void);

void OpenTmr0(void);